import Timetable from './Timetable/TimeTable';

function App() {
  return (
    <div>
      <Timetable />
    </div>
  );
}

export default App;
